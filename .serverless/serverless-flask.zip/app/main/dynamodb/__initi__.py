from flask_dynamo import Dynamo

db = Dynamo()