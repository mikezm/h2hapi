from flask_mongoengine import MongoEngine

db = MongoEngine()

